<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjumlahan Variable</title>
</head>
<body>
    <?php
        $x = 12 ;
        $y = 3 ;
        echo $x + $y;
        echo "<br>";
        $nama = "Halo nama saya Hendra";
        $jurusan = "kuliah Jurusan Teknik Informatika";
        echo $nama." ".$jurusan;
    ?>
</body>
</html>
