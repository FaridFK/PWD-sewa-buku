<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operator Penugasan</title>
</head>
<body>
    <?php
        $x = 100;
        echo $x;echo "<br>";//operator penugasan sama dengan 
        $x += 5;
        echo $x;echo "<br>";//operator penugasan penambahan
        $x -= 5;
        echo $x;echo "<br>";//operator penugasan pengurangan
        $x /= 2;
        echo $x;echo "<br>";//operator penugasan pembagian
        $x %= 35;
        echo $x;echo "<br>";//operator penugasan hasil bagi
        $x ^= 2;
        echo $x;echo "<br>";//operator penugasan hasil bagi
    ?>
</body>
</html>
