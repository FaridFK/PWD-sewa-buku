<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penggabungan Variable Dan String</title>
</head>
<body>
    <?php
        $prodi = "Teknik Informatika";
        echo "Saya mahasiswa jurusan $prodi di Politeknik Negeri Semarang <br>";
        echo "Saya mahasiswa jurusan ".$prodi." di Politeknik Negeri Semarang <br>";
        print("Saya mahasiswa jurusan $prodi di Politeknik Negeri Semarang <br>");
    ?> 
</body>
</html>
