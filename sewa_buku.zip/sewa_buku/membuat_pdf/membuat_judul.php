<?php
    require_once($_SERVER["DOCUMENT_ROOT"] . "/sewa_buku/membuat_pdf/fpdf.php");

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->setFont("Courier", "B", 16);
    $pdf->SetTextColor(255, 255, 255);
    $judul = "BIODATAKU";
    $pdf->MultiCell(185, 12, $judul, 1, "C", true);

    $pdf->SetFont("Times", "", 12);
    $pdf->SetTextColor(220, 20, 60);
    $biodata = "Halo, nama saya Ichsan Alfianto, ".
                "Saya mahasiswa jurusan Teknik Elektro Polines".
                "Hobi saya adalah nonton film, bermain game, membuat video ".
                "saya sering mengcoding, walaupun sangat memusingkan";
    
    $pdf->SetXY(20, 30);
    $pdf->MultiCell(170, 5, $biodata, 1, "C");

    $pdf->SetFont("Times", "", 12);
    $pdf->SetTextColor(27, 128, 1);
    $biodata = "Halo, nama saya Ichsan Alfianto, ".
                "Saya mahasiswa jurusan Teknik Elektro Polines".
                "Hobi saya adalah nonton film, bermain game,membuat video ".
                "saya sering mengcoding, walaupun sangat memusingkan";
    
    $pdf->SetXY(30, 50);
    $pdf->MultiCell(120, 5, $biodata, 1, "C");

    $pdf->Output();
?>
