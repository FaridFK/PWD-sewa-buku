<?php
    require_once($_SERVER["DOCUMENT_ROOT"] . "/sewa_buku/membuat_pdf/fpdf.php");
    $daftar_ibu_kota = array(
        array("Jakarta", "Indonesia"),
        array("Bangkok", "Thailand"),
        array("Tokyo", "Jepang"),
        array("Taipeh", "Taiwan"),
        array("Amsterdam", "Belanda"),
        array("Paris", "Perancis"),
        array("Roma", "Italia"));
    //Buat PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    //Buat judul file PDF
    $pdf->SetFillColor(0, 200, 200);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFont("Arial", "B");
    $pdf->Cell(30, 7, "Ibu Kota", 1, 0, "L", true);
    $pdf->Cell(30, 7, "Negara", 1, 0, "L", true);
    $pdf->Ln();
    //Atur warna untuk selain judul
    $pdf->SetFillColor(255, 255, 255);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Times");
    //tampilkan data
    for($i = 0; $i < count($daftar_ibu_kota); $i++){
        $pdf->Cell(30, 7, $daftar_ibu_kota[$i][0],1,0,"L",true);
        $pdf->Cell(30, 7, $daftar_ibu_kota[$i][1],1,0,"L",true);
        $pdf->Ln();
    }
    $pdf->Output();
?>
