<?php
    require_once($_SERVER["DOCUMENT_ROOT"] . "/sewa_buku/membuat_pdf/fpdf.php");
    $pemakai = "root";
    $password = "";
    $id_mysql = mysqli_connect("localhost", $pemakai, $password);
    if(! $id_mysql)
        die("Gagal melakukan kondisi ke Database server MySQL");
    if(! mysqli_select_db($id_mysql, "sewa_buku"))
        die("Database tidak bisa dipilih");
    $hasil = mysqli_query($id_mysql, "SELECT * FROM data_peminjaman ORDER BY nama_peminjam");
    if(! $hasil)
        die("Permintaan gagal dilaksanakan");
        //buat PDF
        $pdf = new FPDF();
        $pdf->AddPage();
        //buat judul file PDF
        $pdf->SetFillColor(95, 158, 160);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetFont("Arial", "B");
        $pdf->Cell(15, 7, "Kode", 1, 0, "L", true);
        $pdf->Cell(50, 7, "Nama Peminjam", 1, 0, "L", true);
        $pdf->Cell(30, 7, "Tanggal Lahir", 1, 0, "L", true);
        $pdf->Cell(70, 7, "Alamat", 1, 0, "L", true);
        $pdf->Cell(25, 7, "Pekerjaan", 1, 0, "L", true);
        $pdf->Ln();
        //atur warna untuk selain judul
        $pdf->SetFillColor(255, 255, 255);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont("Times");
        $pencacah = 0;
        while($baris = mysqli_fetch_row($hasil)){
            $pdf->Cell(15, 7, $baris[1],1,0,"L",true);
            $pdf->Cell(50, 7, $baris[2],1,0,"L",true);
            $pdf->Cell(30, 7, $baris[4],1,0,"L",true);
            $pdf->Cell(70, 7, $baris[5],1,0,"L",true);
            $pdf->Cell(25, 7, $baris[6],1,0,"L",true);
            $pdf->Ln();
            $pencacah++;
        }
        mysqli_close($id_mysql);
        $pdf->Output();
?>
