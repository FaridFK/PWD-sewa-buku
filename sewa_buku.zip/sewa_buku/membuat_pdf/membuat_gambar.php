<?php
    require_once($_SERVER["DOCUMENT_ROOT"] . "/sewa_buku/membuat_pdf/fpdf.php");
    //buat PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->setFont("Arial", "B", 28);
    $pdf->Cell(100, 12, "LAWANG SEWU");
    $pdf->Image($_SERVER["DOCUMENT_ROOT"] . 
                "/sewa_buku/membuat_pdf/lawang_sewu.jpg", 10, 30);
    $pdf->SetFont("Times", "", 12);
    $teks = "Sebuah gedung tua peninggalan kolonial Belanda terlihat berdiri tegak dijantung Kota Semarang.
            Gelap, kosong, eksotis, sekaligus mistis. Kesan itulah yang terpancar dari Lawang Sewu, bagunan tuan yang berada didekat Tugu Muda Semarang, Jawa Tengah.
            Secara harfiah, Lawang Sewu berarti seribu pintu, meski sebenarnya jumlah pintunya tidak sebanyak itu.
            Gedung ini awalnya dibuangun sebagai kantor pusat Nederlandsch-Indische Spoorweg Maatschappij (NIS), perusahaan kereta api swasta masa Hindia Belanda.";
    $pdf->SetXY(125, 30);
    $pdf->MultiCell(0, 10, $teks, 0, "L ");
    $pdf->Output();
?>
