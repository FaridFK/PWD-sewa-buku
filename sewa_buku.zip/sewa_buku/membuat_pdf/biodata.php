<?php
    require_once($_SERVER["DOCUMENT_ROOT"] . "/sewa_buku/membuat_pdf/fpdf.php");

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->setFont("Arial", "", 12);
    $biodata = "Halo, nama saya Ichsan Alfianto, ".
                "Saya mahasiswa jurusan Teknik Elektro Polines".
                "Hobi saya adalah nonton film, bermain game, membuat Video ".
                "saya sering mengcoding, walaupun sangat memusingkan";
    
    $pdf->setX(80);
    $pdf->MultiCell(0, 5, $biodata, 1, "R");
    $pdf->Output();
?>
