<?php
    include "config.php";
    $db = new Database();
    $username = $_POST['username'];
    $password = $_POST['password'];

    foreach($db->login($usename, $password) as $x){
        session_start();
        $_SESSION["username"] = $username;
        $_SESSION["password"] = $password;
        $akses_id = $x['akses_id'];
        $pass = $x['password'];

        if(($akses_id == '1') AND ($password==$pass)){
            header('Location: halaman_admin.php');
        }
        else if(($akses_id == '2') AND ($password==$pass)){
            header('Location: halaman_peminjam.php');
        }
        else{
            header('Location: login.php');
        }
    }
?>
