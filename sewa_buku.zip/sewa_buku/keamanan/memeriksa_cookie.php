<?php
    $cookie_name = "user";
    $cookie_value = "Karina";
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
    if(count($_COOKIE) > 0) {
        echo "Cookies ada.";
    } else {
        echo "Cookies tidak ada.";
    }
?>
