<?php
    setcookie("username", "Anita", time()+1800);
?>
