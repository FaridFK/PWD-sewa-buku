<?php
session_start();

$_SESSION["username"] = "nama_user";
$_SESSION["password"] = "password123";
echo 'Username : ' . $_SESSION["username"]."<br>";
echo 'Password : ' . $_SESSION["password"];
?>
