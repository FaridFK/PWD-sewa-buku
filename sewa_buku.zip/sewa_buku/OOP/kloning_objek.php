<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kloning Objek</title>
</head>
<body>
    <?php
        $object1 = new User();
        $object1->name = "Alisa";
        $object2 = clone $object1;
        $object2->name = "Amira";
        echo "object1 name = " . $object1->name . "<br>";
        echo "object2 name = " . $object2->name;

        class User{
            public $name;
        }
    ?>
</body>
</html>
