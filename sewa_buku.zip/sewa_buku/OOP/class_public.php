<?php
    //buat class kuliah
    class kuliah{
        //buat public properti
        public $nama_mahasiswa;
        //buat public method
        public function masuk_kuliah(){
            return " masuk kuliah";
        }
    }
    //buat objek dari class kuliah(instansiasi)
    $kuliah_anto = new kuliah();
    //set properti
    $kuliah_anto->nama_mahasiswa="Anto";
    //tampilkan properti
    echo $kuliah_anto->nama_mahasiswa; //Anto
    //tampilkan method
    echo $kuliah_anto->masuk_kuliah(); //"masuk kuliah"
?>
