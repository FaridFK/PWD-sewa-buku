<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metode 2</title>
</head>
<body>
    <?php
        //buat class laptop
        class laptop{
            //buat method untuk class laptop
            public function hidupkan_laptop($pemilik="Joko",$merk="Samsung"){
                return "Hidupkan laptop $merk punya $pemilik";
            }
        }
        //buat objek dari class laptop(instansiasi)
        $laptop_andi= new laptop();
        echo $laptop_andi->hidupkan_laptop();
        //hasil: "Hidupkan laptop Samsung punya Joko";
        echo "<br />";
        echo $laptop_andi->hidupkan_laptop("Andi", "Lenovo");
        //hasil: "Hidupkan laptop lenovo punya Andi";
    ?>
</body>
</html>
