<?php
    //buat class laptop
    class kuliah{
        //buat protected properti
        protected $nama_mahasiswa;
        //buat protected method
        protected function masuk_kuliah(){
            return "Hidupkan Laptop";
        }
    }
    //buat objek dari class mahasiswa (instansiasi)
    $mahasiswa_anto = new kuliah();
    //set protected properti akan menghasilkan error
    $mahasiswa_anto->nama_mahasiswa="Anto";
    //Fatal error: Cannot access protected properti mahasiswa::$nama_mahasiswa

    //tampilkan protected properti akan menghasilkan error
    echo $mahasiswa_anto->nama_mahasiswa;
    //Fata error: Cannot access protected properti mahasiswa::$nama_mahasiswa

    //jalankan protected method akan menghasilkan error
    echo $mahasiswa_anto->masuk_kuliah();
?>
