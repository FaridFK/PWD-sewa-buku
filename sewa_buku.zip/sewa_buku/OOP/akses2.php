<?php
    //buat class laptop
    class laptop{
        //buat properti untuk class laptop
        var $pemilik;
        var $merk;
        var $ukuran_layar;
        //buat method untuk class laptop
        function hidupkan_laptop(){
            return "Hidupkan Laptop";
        }
        function matikan_laptop(){
            return "Matikan Laptop";
        }
    }
    //buat objek dari class laptop (intansiasi)
    $laptop_baru = new laptop();
    //set properti
    $laptop_baru->pemilik = "Wira";
    $laptop_baru->merk = "Accer";
    $laptop_baru->ukuran_layar = "14 inchi";
    //tampilkan properti
    echo $laptop_baru->pemilik;echo "<br>";
    echo $laptop_baru->merk;echo "<br>";
    echo $laptop_baru->ukuran_layar;echo "<br>";
    //tampilkan method
    echo $laptop_baru->hidupkan_laptop();echo"<br>";
    echo $laptop_baru->matikan_laptop();
?>
