<?php
    //buat class laptop
    class laptop{
        //buat properti untuk class laptop
        var $pemilik;
        //buat method untuk class laptop
        function hidupkan_laptop(){
            return "Hidupkan Laptop";
        }
    }
    //but objek dari class laptop (instansiasi)
    $laptop_anto = new laptop();
    $laptop_andi = new laptop();
    $laptop_dina = new laptop();
    //set properti
    $laptop_anto->pemilik = "Anto";
    $laptop_andi->pemilik = "Andi";
    $laptop_dina->pemilik = "Dina";
    //tampilkan properti
    echo $laptop_anto->pemilik;echo "<br>";
    echo $laptop_andi->pemilik;echo "<br>";
    echo $laptop_dina->pemilik;echo "<br>";
?>
