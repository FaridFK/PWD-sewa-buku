<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deret Bilangan Prima</title>
</head>
<body>
<h1>Menampilkan bilangan prima dari 1 s/d 100</h1>
<?php
    for ($i=1; $i <= 100 ; $i++) {     // for 1, adalah bilangan yang akan di cek
        $t = 0; 
        
            for ($j=1; $j <= $i ; $j++) {  // for 2, bilangan pembagi
                if ($i % $j == 0) {
                    $t++;
                }
            }
            
        if ($t == 2) {   // syarat atau kondisi bilangan prima
            echo $i."<br>";
        }
    }
?>
</body>
</html>
