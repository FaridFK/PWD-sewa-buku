<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Switch Case</title>
</head>
<body>
    <?php
        $buah = "apel";
        switch($buah){
            case "mangga":
                echo "buah is apple";
            break;
            case "jeruk":
                echo "buah is bar";
            break;
            case "anggur":
                echo "buah is cake";
            break;
            default:
                echo "buah favorit anda tidak tersedia";
        }
    ?>
</body>
</html>
