<?php
class Bunga{
    public $nama;
    public $warna;
    public function __construct($nama, $warna)
    {
        $this->nama = $nama;
        $this->warna = $warna;
    }
    public function ciri(){
        echo "Bunga {$this->nama} berwarna {$this->warna}.";
    }
}

class Anggrek extends Bunga {
    public function jenis_bunga(){
        echo "bunga favorit saya ";
    }
}

$anggrek_ungu = new Anggrek("Anggrek", "ungu");
$anggrek_ungu->jenis_bunga();
$anggrek_ungu->ciri();
?>
