<?php
    //cara 1
    $hobi = array("Rebahan", "Tiktokan", "Videografi", "Bikin konten youtube");

    //cara 2
    $minuman_favorit = ["Boba", "Kopi Brown Sugar", "Dalgona Coffee", "Cheese Tea", "Coklat Regal"];

    print_r($hobi);

    echo "<br>";    //pindah baris

    print_r($minuman_favorit);
?>
