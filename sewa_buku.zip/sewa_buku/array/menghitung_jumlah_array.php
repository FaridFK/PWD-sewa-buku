<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menghitung Jumlah Array</title>
</head>
<body>
    <?php
        $minuman_favorit = ["Boba", "Kopi Brown Sugar", "Dalgona Coffee", "Cheese Tea", "Coklat Regal"];

        $jumlah_minuman_favorit = count($minuman_favorit);

        echo "Jumlah minuman kesukaan saya adalah ".$jumlah_minuman_favorit;
    ?>
</body>
</html>
