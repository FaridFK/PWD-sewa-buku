<?php
    // Membuat koneksi ke database
    $conn = mysqli_connect("localhost","root","","stokbarang");
    if(mysqli_connect_errno())
    {
        echo "Koneksi database gagal: " . mysqli_connect_errno();
    }
    else{
        // echo "Sukses konek";
    }
    // menambah barang baru
    if(isset($_POST['addnewbarang'])){
        $namabarang = $_POST['namabarang'];
        $deskripsi = $_POST['deskripsi'];
        $stock = $_POST['stock'];
        $addtotable = mysqli_query($conn, "INSERT INTO stock (namabarang, deskripsi, stock) values('$namabarang','$deskripsi','$stock')");
        if($addtotable){
            header('location:index.php');
        }else{
            echo 'Gagal';
            header('location:index.php');
        }
    }
    // menambah barang masuk
    if(isset($_POST['barangmasuk'])){
        $barangnya = $_POST['barangnya'];
        $penerima = $_POST['penerima'];
        $qty = $_POST['qty'];
        $cekstocksekarang = mysqli_query($conn, "SELECT * FROM stock where idbarang='$barangnya'");
        $ambildatanya = mysqli_fetch_array($cekstocksekarang);
        $stocksekarang = $ambildatanya['stock'];
        $tambahkanstocksekarangqty = $stocksekarang + $qty;
        $addtomasuk = mysqli_query($conn, "INSERT INTO masuk (idbarang, keterangan, qty) values('$barangnya','$penerima','$qty')");
        $updatestockmasuk = mysqli_query($conn, "UPDATE stock set stock='$tambahkanstocksekarangqty' where idbarang = '$barangnya'");
        if ($addtomasuk&&$updatestockmasuk) {
            header('location:masuk.php');
        } else {
            echo 'Gagal';
            header('location:masuk.php');
        }
    }
    if (isset($_POST['addbarangkeluar'])) {
        $barangnya = $_POST['barangnya'];
        $penerima = $_POST['penerima'];
        $qty = $_POST['qty'];
        $cekstocksekarang = mysqli_query($conn, "SELECT * FROM stock where idbarang='$barangnya'");
        $ambildatanya = mysqli_fetch_array($cekstocksekarang);
        $stocksekarang = $ambildatanya['stock'];
        $tambahkanstocksekarangqty = $stocksekarang - $qty;
        $addtokeluar = mysqli_query($conn, "INSERT INTO keluar (idbarang, penerima, qty) values('$barangnya','$penerima','$qty')");
        $updatestockeluar = mysqli_query($conn, "UPDATE stock set stock='$tambahkanstocksekarangqty' where idbarang = '$barangnya'");
        if ($addtokeluar && $updatestockeluar) {
            header('location:keluar.php');
        } else {
            echo 'Gagal';
            header('location:keluar.php');
        }
    }
?>