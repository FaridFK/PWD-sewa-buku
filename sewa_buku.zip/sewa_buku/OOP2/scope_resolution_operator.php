<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scope Resolution Operator</title>
</head>
<body>
    <?php
        // buat class bunga
        class bunga {
            public function lihat_bunga() {
                return "Nama bungan: mawar,
                Warna: merah, Lokasi: taman depan";
            }
        }
        // turunkan class bungan ke anggrek
        class anggrek extends bunga {
            public function lihat_bunga() {
                return "Nama bungan: anggrek,
                Warna: ungu, Lokasi: di pohon mangga";
            }
            public function lihat_jenis_bunga() {
                return parent::lihat_bunga();
            }
        }
        $anggrek_baru = new anggrek();                      // buat objek dari class anggrek (instansiasi)
        echo $anggrek_baru->lihat_bunga();echo "<br />";    // panggil method lihat_bunga()
        echo $anggrek_baru->lihat_jenis_bunga();            // panggil method lihat_jenis_bunga()
    ?>
</body>
</html>
