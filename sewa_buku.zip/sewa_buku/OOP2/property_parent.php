<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Parent</title>
</head>
<body>
    <?php
        // buat class mahasiswa
        class mahasiswa {
            public function data_mahasiswa() {
                return "Nama mahasiswa: Marisa,
                nim: 12345678, Alamat: Yogyakarta";
            }
        }
        // turunkan class mahasiswa ke mhs_informatika
        class mhs_informatika extends mahasiswa {
            public function data_mahasiswa() {
                return "Nama mahasiswa: Marisa,
                nim: 12345678, Alamat: Yogyakarta";
            }
        }
        // buat objek dari class laptop (instansiasi)
        $mahasiswa_baru = new mhs_informatika();
        //panggil method lihat_spec()
        echo $mahasiswa_baru->data_mahasiswa();
    ?>
</body>
</html>
