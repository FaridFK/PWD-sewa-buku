<?php
    echo cos(0)."<br>";
    echo acos(0.5)."<br>";
    echo sin(0)."<br>";
    echo asin(1)."<br>";
    echo tan(0)."<br>";
    echo atan(0.5)."<br>";
    echo pi()."<br>";
    echo abs(-0.5)."<br>"; //fungsi untuk memperoleh nilai absolute    
    echo exp(1)."<br>"; //fungsi untuk memperoleh nilai eksponen
    echo log(10)."<br>"; //fungsi untuk memperoleh nilai logaritma
    echo log10(2)."<br>"; //fungsi untuk memperoleh nilai logaritma (basis 10)
    echo pow(2, 3)."<br>"; //fungsi untuk memperoleh nilai perpangkatan
    echo sqrt(81)."<br>"; //fungsi untuk memperoleh nilai akar
    echo max(15,2)."<br>"; //fungsi untuk memperoleh nilai terbesar
    echo min(13, 4)."<br>"; //fungsi untuk mencari nilai terkecil
?>
