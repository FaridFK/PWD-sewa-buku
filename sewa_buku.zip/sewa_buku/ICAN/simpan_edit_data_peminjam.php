<?php
    include "config.php";
        $jenis_kelamin = $_POST['jeni_kelamin'];
        if($jenis_kelamin == "Perempuan"){
            $kode_jk = 'P';
        }
        else if($jenis_kelamin == "Laki-laki"){
            $kode_jk = 'L';
        }
    $koneksi = new Database();
    $koneksi->edit_data_peminjam($_POST['kode_peminjam'] , $_POST['nama_peminjam'] , $_POST['jenis_kelamin'] , $_POST['tanggal_lahir'] , $_POST['alamat'] , $_POST['pekerjaan']);
    header('Location:tampilkan_data_peminjam.php');
?>