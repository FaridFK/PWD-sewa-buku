<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="simpan_form_upload_file.php" enctype="multipart/form-data">
    Nama file : <input type="file" name="foto_profil"><br>
    <input type="submit" value="Upload">
    </form>
</body>
</html>