<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konoha TV</title>
</head>
<body>
    <?php
        include "halaman1.php";
        include "halaman2.php";
        echo "Menyediakan berbagai macam channel tayangan berkualitas, serta berbagai layanan TV kabel/nirkabel dengan harga murah :)";
    ?>
</body>
</html>
