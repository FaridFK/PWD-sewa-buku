<h3>Jl. Raya Semarang no 54</h3>
<h3>Semarang</h3>
<h3>Buka setiap Senin - Sabtu, jam 07:30 - 17:00</h3>
<h3>Hari Minggu, Hari raya, Hari libur/tanggal merah libur</h3>
