<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="popper.min.js" crossorigin="anonymous"></script>
    <script src="bootstrap.min.js" crossorigin="anonymous"></script>
    <title>Sewa Buku</title>
  </head>
  <body>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="a">Home</a>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="tampil_peminjaman_peminjam.php">Peminjaman</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tampil_data_buku_peminjam.php">Daftar Buku</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="setting_peminjam.php?id=<?php echo $_SESSION['username']; ?>">Setting</a>
                    </li>
                </ul>
                <form class="d-flex" style="margin-left:auto;">
                <input class="form-control me-2" type="text" placeholder="Search">
                <button class="btn btn-primary" type="button">Search</button>
                </form>  
                <a href="logout.php"><button class="btn btn-outline-danger" type="button">LOG OUT</button></a>
            </div>
        </div>
        </nav>
        <!-- <?php  echo $_SESSION['username']; ?> -->
</body>
</html>
