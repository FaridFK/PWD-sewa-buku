<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>LOGIN</title>
</head>
<body>
    <div class="d-flex aligns-items-center justify-content-center" style="height: 100vh;">
      <div class="card-body">
        <h2>LOGIN</h2>
          <form action="validasi_login.php" method="post">
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" id="username" placeholder="Masukkan Username" name="username" required>
            </div>
            <hr>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" placeholder="Masukkan Password" name="password" required>
            </div>
            <hr>
            <div class="d-grid">
              <button type="submit" class="btn btn-outline-success">LOGIN</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</body>
</html>
