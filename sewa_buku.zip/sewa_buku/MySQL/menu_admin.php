
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="a">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav me-auto">

                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data Buku</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tambah_data_buku.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampil_data_buku.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data Jenis Buku</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tambah_data_jenis_buku.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampil_data_jenis_buku.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data Peminjam</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tambah_data_peminjam.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampilkan_data_peminjam.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data Penerbit</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tambah_data_penerbit.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampil_data_penerbit.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data pengarang</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tambah_data_pengarang.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampil_data_pengarang.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Peminjaman</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="peminjaman_buku.php">Tambah Data</a></li>
                        <li><a class="dropdown-item" href="tampil_peminjaman.php">Tampilkan Data</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Data User</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item disabled" href="#">Tambah Data</a></li>
                        <li><a class="dropdown-item disabled" href="#">Tampilkan Data</a></li>
                    </ul>
                </li>
            </ul>
            <form class="d-flex" style="margin-left:auto;">
                <input class="form-control me-2" type="text" placeholder="Search">
                <button class="btn btn-primary" type="button">Search</button>
                </form> 
            <a href="logout.php"><button class="btn btn-outline-danger" type="button">LOG OUT</button></a>
        </div>
    </div>
</nav>
