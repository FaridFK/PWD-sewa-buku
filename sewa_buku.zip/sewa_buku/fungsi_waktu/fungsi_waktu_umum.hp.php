<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fungsi Waktu Umum</title>
</head>
<body>
    <?php
        var_dump(checkdate(9,30,2003));
        echo "<br>";
        var_dump(checkdate(2,30,2003));
        echo "<br>";
        echo date("d m Y")."<br>";
        echo date("D, d f Y, G:i:s")."<br>";
        echo date("G A");
    ?>  
</body>
</html>
