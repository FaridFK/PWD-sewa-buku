<?php

class database
{
    var $host = "localhost";
    var $username = "root";
    var $password = "";
    var $database = "sewa_buku";
    var $koneksi = "";

    function __construct()
    {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if (mysqli_connect_errno()) {
            echo "Koneksi database gagal : " . mysqli_connect_errno();
        } 
    }
    function tampil_data()
    {
        $query = "SELECT a.* , b.* FROM data_peminjaman a INNER JOIN jenis_kelamin b ON b.kode_jk = a.jenis_kelamin";
        $data = mysqli_query($this->koneksi, $query);
        while ($row = mysqli_fetch_array($data)) {
            $hasil[] = $row;
        }
        return $hasil;
    }
    function tampil_data_jenis_kelamin()
    {
        $query = "SELECT * FROM jenis_kelamin";
        $data_jenis_kelamin = mysqli_query($this->koneksi, $query);
        while ($row_jenis_kelamin = mysqli_fetch_array($data_jenis_kelamin)) {
            $hasil_jenis_kelamin[] = $row_jenis_kelamin;
        }
        return $hasil_jenis_kelamin;
    }
    function tambah_data_peminjam($kode_peminjam, $nama_peminjam, $jenis_kelamin, $tanggal_lahir, $alamat, $pekerjaan, $foto)
    {
        mysqli_query($this->koneksi, "INSERT INTO data_peminjaman VALUES ('' , '$kode_peminjam' , '$nama_peminjam' , '$jenis_kelamin' , '$tanggal_lahir' , 
                    '$alamat' , '$pekerjaan' , '$foto' , '')");
        $ambil_id = mysqli_query($this->koneksi, "select id from data_peminjaman ORDER BY id DESC LIMIT 1");
        $row_id = mysqli_fetch_array($ambil_id);
        $hasil_id = $row_id['id'];
        mysqli_query($this->koneksi, "insert into values ('','$kode_peminjam','$kode_peminjam','2','$hasil_id')");
    }
    function kode_peminjam($kode_peminjam)
    {
        $query = "SELECT a.* , b.* FROM data_peminjaman a INNER JOIN jenis_kelamin b ON b.kode_jk = a.jenis_kelamin WHERE a.kode_peminjam='$kode_peminjam' ";
        $data_peminjam = mysqli_query($this->koneksi, $query);

        while ($row_peminjam = mysqli_fetch_assoc($data_peminjam)) {
            $hasil_peminjam[] = $row_peminjam;
        }
        return $hasil_peminjam;
    }
    function edit_data_peminjam($kode_peminjam, $nama_peminjam, $jenis_kelamin, $tanggal_lahir, $alamat, $pekerjaan, $foto)
    {
        mysqli_query($this->koneksi, "UPDATE data_peminjaman SET nama_peminjam = '$nama_peminjam' , jenis_kelamin = '$jenis_kelamin' , 
                    tanggal_lahir = '$tanggal_lahir' , alamat = '$alamat' , pekerjaan = '$pekerjaan' , foto = '$foto' 
                    WHERE kode_peminjam = '$kode_peminjam' ");
    }
    function hapus_data_peminjam($kode_peminjam)
    {
        mysqli_query($this->koneksi, "DELETE from data_peminjaman WHERE kode_peminjam = '$kode_peminjam' ");
    }
}
?>
