<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Data Peminjam</title>
</head>
<body>
    <?php
        include "config.php";
        $db = new Database();
    ?>
        <table border="1">
            <tr>
                <th>No</th>
                <th>Kode Peminjam</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Pekerjaan</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
            <?php 
            $no = 1;
            foreach ($db->tampil_data() as $x) {
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $x['kode_peminjam']; ?></td>
                <td><?php echo $x['nama_peminjam']; ?></td>
                <td><?php echo $x['keterangan_jk']; ?></td>
                <td>
                    <?php
                        $tanggal_lahir = $x['tanggal_lahir'];
                        $tanggal_lahir_ganti_format = date("d-m-Y" , strtotime($tanggal_lahir));
                        echo $tanggal_lahir_ganti_format;
                    ?>
                </td>
                <td><?php echo $x['alamat']; ?></td>
                <td><?php echo $x['pekerjaan']; ?></td>
                <td>
                <?php
                    if(empty($x['foto'])){
                ?>
                <?php
                    }
                    else{
                ?>
                    <img src="<?php echo $x['foto']; ?>" alt="" width="50" height="50">
                <?php
                    }
                ?>
                </td>
                <td>
                    <a href="edit_data_peminjam.php?id=<?php echo $x['kode_peminjam']; ?>"><button class="btn btn-outline-primary">Edit</button></a>
                    <a href="hapus_data_peminjam.php?id=<?php echo $x['kode_peminjam']; ?>"><button class="btn btn-outline-primary">Hapus</button></a>
                </td>
            </tr>
            <?php
            }
            ?>
        </table>
</body>
</html>
