<?php

$mahasiswa = array

  (

  array("Mariska",19,"Semarang"),

  array("Benny",18,"Jayapura"),

  array("Jessy",19,"Pontianak"),

  array("Laras",17,"Tegal")

  );

echo "Nama : ". $mahasiswa[1][0].", Usia: ".$mahasiswa[1][1].", Alamat: ".$mahasiswa[1][2].".<br>";

?>
