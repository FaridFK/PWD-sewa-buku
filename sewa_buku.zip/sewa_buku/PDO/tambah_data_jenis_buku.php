<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Jenis Buku</title>
</head>
<body>
    <div class="container p-5">
    <h1>Tambah Data Jenis Buku</h1>
    <?php
        include "config.php";
    ?>
    <form action="simpan_data_jenis_buku.php" method="post">
        <table>
            <tr>
                <td>Kode Jenis Buku</td>
                <td>:</td>
                <td><input type="text" name="kode_jenis_buku" class="form-control" placeholder="Masukkan Kode Jenis Buku"></td>
            </tr>
            <tr>
                <td>Nama Jenis Buku</td>
                <td>:</td>
                <td><input type="text" name="nama_jenis_buku" id="" class="form-control" placeholder="Masukkan Nama Jenis Buku"></td>
            </tr>
            <tr>
                <td colspan="3"><div class="d-grid"><input type="submit" value="SIMPAN" class="btn btn-outline-success"></div></td>
            </tr>
        </table>
    </form>
    </div>
</body>
</html>
