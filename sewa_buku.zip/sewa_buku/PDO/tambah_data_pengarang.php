<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data pengarang</title>
</head>
<body>
    <div class="container p-5">
    <h1>Tambah Data pengarang</h1>
    <?php
        include "config.php";
    ?>
    <form action="simpan_data_pengarang.php" method="post">
        <table border="1">
            <tr>
                <td>Kode Pengarang</td>
                <td>:</td>
                <td><input type="text" name="kode_pengarang" class="form-control" placeholder="Masukkan Kode Pengarang"></td>
            </tr>
            <tr>
                <td>Nama Pengarang</td>
                <td>:</td>
                <td><input type="text" name="nama_pengarang" id="" class="form-control" placeholder="Masukkan Nama pengarang"></td>
            </tr>
            <tr>
                <td colspan="3"><div class="d-grid"><input type="submit" value="SIMPAN" class="btn btn-outline-success"></div></td>
            </tr>
        </table>
    </form>
    </div>
</body>
</html>
